var req;

// FUNÇÃO PARA BUSCA NOTICIA
function buscarUsuarios(valor,pagina,ordem,tipo) {
console.log("processando");
console.log(valor);
console.log(pagina);


// Verificando Browser
if(window.XMLHttpRequest) {
   req = new XMLHttpRequest();
}
else if(window.ActiveXObject) {
   req = new ActiveXObject("Microsoft.XMLHTTP");
}

// Arquivo PHP juntamente com o valor digitado no campo (método GET)
var url = "busca.php?valor="+valor+"&pagina="+pagina+"&ordem="+ordem+"&tipo="+tipo;

// Chamada do método open para processar a requisição
req.open("Get", url, true);

// Quando o objeto recebe o retorno, chamamos a seguinte função;
req.onreadystatechange = function() {

	// Exibe a mensagem "Buscando Noticias..." enquanto carrega
	if(req.readyState == 1) {
		document.getElementById('resultado').innerHTML = 'Buscando Usuários...';
	}

	// Verifica se o Ajax realizou todas as operações corretamente
	if(req.readyState == 4 && req.status == 200) {

	// Resposta retornada pelo busca.php
	var resposta = req.responseText;

	// Abaixo colocamos a(s) resposta(s) na div resultado
	//document.getElementById('resultado').innerHTML = resposta;
	//alert('oi111');
	//document.getElementById('products-table').append(resposta);
	document.getElementById('products-table').innerHTML = resposta;

	//Adicionar(resposta);
	}
}
req.send(null);
}


// FUNÇÃO PARA EXIBIR NOTICIA
function exibirConteudo(id) {

// Verificando Browser
if(window.XMLHttpRequest) {
   req = new XMLHttpRequest();
}
else if(window.ActiveXObject) {
   req = new ActiveXObject("Microsoft.XMLHTTP");
}

// Arquivo PHP juntamento com a id da noticia (método GET)
var url = "exibir.php?id="+id;

// Chamada do método open para processar a requisição
req.open("Get", url, true);

// Quando o objeto recebe o retorno, chamamos a seguinte função;
req.onreadystatechange = function() {

	// Exibe a mensagem "Aguarde..." enquanto carrega
	if(req.readyState == 1) {
		document.getElementById('conteudo').innerHTML = 'Aguarde...';
	}

	// Verifica se o Ajax realizou todas as operações corretamente
	if(req.readyState == 4 && req.status == 200) {

	// Resposta retornada pelo exibir.php
	var resposta = req.responseText;

	// Abaixo colocamos a resposta na div conteudo
	document.getElementById('conteudo').innerHTML = resposta;
	//alert('oi');
	AddTableRow(resposta);
	}
}
req.send(null);
}

function Adicionar(coisas){
    $("#products-table tbody").append(coisas);

};


(function($) {

  RemoveTableRow = function(handler) {
    var tr = $(handler).closest('tr');

    tr.fadeOut(400, function(){
      tr.remove();
    });

    return false;
  };

  AddTableRow = function(coisas) {

      // var newRow = $("<tr>");
      // var cols = "";

      // cols += '<td>&nbsp;</td>';
      // cols += '<td>&nbsp;</td>';
      // cols += '<td>&nbsp;</td>';
      // cols += '<td>&nbsp;</td>';

      // cols += '<td class="actions">';
      // cols += '<button class="btn btn-large btn-danger" onclick="RemoveTableRow(this)" type="button">Remover</button>';
      // cols += '</td>';

      // newRow.append(cols);

      $("#products-table").append($(coisas));

      return false;
  };

})(jQuery);
